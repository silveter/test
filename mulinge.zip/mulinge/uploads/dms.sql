-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2019 at 08:47 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dms`
--

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `FileID` int(10) NOT NULL,
  `FileName` varchar(50) NOT NULL,
  `FileType` varchar(50) NOT NULL,
  `FileSize` int(100) NOT NULL,
  `SourceLocation` varchar(100) NOT NULL,
  `UploadLocation` varchar(100) NOT NULL,
  `UploadUser` varchar(20) NOT NULL,
  `SharedState` char(1) NOT NULL DEFAULT 'N',
  `SharedBy` varchar(20) NOT NULL DEFAULT 'NONE',
  `SharedTo` varchar(20) NOT NULL DEFAULT 'NONE',
  `ShareDateTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `UploadDateTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserName` varchar(20) NOT NULL,
  `FirstName` varchar(20) NOT NULL,
  `OtherNames` varchar(20) NOT NULL,
  `PhoneNum` int(10) NOT NULL,
  `Password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserName`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
