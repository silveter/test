<!DOCTYPE html>
<html>
    <head>
        <title> Order Page</title>
    </head>

<style>

</style>
    <body>
<table style="margin-bottom:20px;margin-top:-250px;color: black;margin-left: 13%;" width="800" border="1" cellpadding="1" cellspacing='1'bgcolor='beige'>
<tr bgcolor="#beebeb">
<th>Order Title</th>
<th>Order Id</th>				
</tr>       
<?php
include 'functions.php';
include 'student_menu.php';

$sql = "select * from orderdetails where assigned=''";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) >0) 

{
    // output data of each row
while ($row = mysqli_fetch_assoc($result)) 

//($row = mysqli_fetch_assoc($result)) 
{
 echo "<tr>"
   
	
	. "<td>".$row["title"]."</td>";
	
echo '<td style="color:black;"><a href="studentview_order.php?id=' . $row["orderid"].'">' . $row['orderid'].'</a></td>';
//echo '<td><a href="studentview_order.php?id=' . $row["orderid"].'">' . $row["orderid"].'</a></td>';

"</tr>";
    }
    
} else {
    echo "";
}

mysqli_close($conn);
?>     
</table>
</body>
</html>