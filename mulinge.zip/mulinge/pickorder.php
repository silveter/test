<?php
include 'functions.php';
include 'admin_menu.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Pick Order</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
	
<?php
		
		//fetch products from the database
		
		$results = $conn->query("SELECT * FROM orderdetails WHERE orderid='".$_GET['id']."'");
		$row = $results->fetch_assoc();
		
?>
    
   <div style="text-align:right;font-family:Segoe UI;transform: translateY(-1100%);font-weight:bold;margin-right:12%;">
	Order Id: <?php echo $_GET['id'];?>
	</div>
  
 <div style="text-align:right;font-family:Segoe UI;transform: translateY(-900%);color: green;font-weight:bold;margin-right:14%;">
  Budget: $<?php echo $row['price']; 
  ?>
  </div>
  <div style="text-align:right;font-family:Segoe UI;transform: translateY(-700%);color: green;font-weight:bold;margin-right:8.5%;">
  Deadline:<?php echo $row['deadline']; 
  ?>
  </div>
   
   
	<table style="transform: translateY(-200%);margin-left: 13%;text-align: left;" width="800" border="1" cellpadding="1" cellspacing='1' bgcolor='beige'>

        <tr bgcolor="#00BFFF">
                     
                     <th>Order Description</th>
					
                     
           </tr>
		   
<?php


if (mysqli_num_rows($results) > 0) {
 echo "<tr>"
    . "<td>".$row["description"]."</td>";
"</tr>";


    
} else {
    echo "0 results";
}

mysqli_close($conn);
?>


      
	 <form id="login-part" action="confirmed.php" method="POST" name="login-form" enctype="multipart/form-data">

        

        </table>
				
  <div style="float:right;" class="row">
		   <input type='hidden' value="<?php echo $_GET['id'];?>" name="pick_id"/> 
           <button style="background-color:#b4d3b2;color: white;font-weight:bold;left: 50%;font-size: 18px;height:35px;
		   margin-left:auto;display:block;margin-right:100px;; width:200px;
		   transform:translateY(-750%);border-radius: 10px; "name="order-submit" type="submit" class="pick_btn"><i class="fa fa-sign-in" 
		   style="font-size:20px;color:green"></i>Pick Now</button>
					
  </div>
  
  <?php
  //include("chatform.php");
  ?>

    </form>
    
</body>
</html>
