<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title></title>
        <link rel="stylesheet" href="Home.css">
    
        </head>
        <body>
            <div id="orange-div">
                <hr class="new1">
                <div class="home">
                    MY HOMEWORK HELP

                </div> 

                <div class="dropdown">
                    <button class="dropbtn">Your Profile 
                        <i class="fa fa-caret-down"></i>
                    </button>
                    <div class="dropdown-content">
                        <a href="login.php?logout='1'" style="color: black;">Change Password</a>		
						<a href="login.php?logout='1'" style="color: black;">Log Out</a>
						
                    </div>
                </div> 



            </div>

            <div id="black-div">
                <hr class="new1">
                |<a href="expert_menu.php">Home</a>|
				
                <a href="tag_a.asp">Services</a>|
				<a href="displayorder.php">Available Orders</a>|				                
                <a href="confirmed.php">In Progress</a>|
				 <a href="confirmed.php">Revisions</a>|
				<a href="displayorder.php">Completed</a>|
				<a href="displayorder.php">Payments</a>|

            </div>
            

        </body>
    </html>

