<?php		
include('functions.php');	date_default_timezone_set("Africa/Nairobi");
$datetimenow = new DateTime("now");

//Generating OrderID

$ordIDq = "SELECT MAX(OrderID) AS OrderID FROM orders";
$ordIDqres = mysqli_query($conn,$ordIDq) or die (Mysqli_error($conn));
$ordIDrow = mysqli_fetch_array($ordIDqres, MYSQLI_ASSOC);
$ab = $ordIDrow['OrderID'];

if($ab == ''){$ordid = "50001";}
else{
	$ordid = $ab+1;
}





	$fname = mysqli_real_escape_string($conn,$_POST['first_name']);
	$datenow=date('Ymd_His');

	$file_name = $_FILES['file_upload']['name'];
	$file_tem_loc = $_FILES['file_upload']['tmp_name'];
	$file_extn = substr($file_name, strrpos($file_name, '.')+1);
	
	$new_file_name_loc="../uploads/".$fname."_".$datenow.".".$file_extn;
	$new_file_name_loc_post="uploads/".$fname."_".$datenow.".".$file_extn;

	if (!file_exists('../uploads')) {
    mkdir('../uploads', 0777, true);
		}
		
	if(move_uploaded_file($file_tem_loc,$new_file_name_loc))	

		{
	$sql = "INSERT INTO orders(OrderID,FirstName,OtherNames,Email,Phone,Country,CountryCode,ProjectTitle,PaperType,SubjectArea,HourBracket,NumPages,
								Price,OrderValue,Description,FileLocation,Deadline,DateCreated,LastModDate,DelFlag)
		VALUES('".$ordid."',
				'".mysqli_real_escape_string($conn,$_POST['first_name'])."',
				'".mysqli_real_escape_string($conn,$_POST['other_names'])."',
				'".mysqli_real_escape_string($conn,$_POST['email'])."',
				'".mysqli_real_escape_string($conn,$_POST['phone_num'])."',
				'".mysqli_real_escape_string($conn,$_POST['country_name'])."',
				'".mysqli_real_escape_string($conn,$_POST['country_code'])."',
				'".mysqli_real_escape_string($conn,$_POST['proj_title'])."',
				'".mysqli_real_escape_string($conn,$_POST['doc_type'])."',
				'".mysqli_real_escape_string($conn,$_POST['sub_area'])."',
				'".mysqli_real_escape_string($conn,$_POST['hours'])."',
				'".mysqli_real_escape_string($conn,$_POST['num_pages'])."',
				'".mysqli_real_escape_string($conn,$_POST['price'])."',
				'".mysqli_real_escape_string($conn,$_POST['order_value'])."',
				'".mysqli_real_escape_string($conn,$_POST['description'])."',
				'".$new_file_name_loc_post."',
				'".mysqli_real_escape_string($conn,$_POST['deadline'])."',
				'".date('Y-m-d H:i:s')."',
				'".date('Y-m-d H:i:s')."'
				,'N')";
$qury = mysqli_query($conn, $sql);


if(!$qury){
	echo"<i class='alerts' style='color:red;font-size:15px;'><i class='fa fa-times'></i> Order not submitted! Please try again.</i>".mysqli_error($conn);
}
   else {
	 echo"<i class='alerts' style='color:green;font-size:15px;'><i class='fa fa-check'></i> Order Submitted successfully</i>";
   
		
	}
	}
	
	else {
		
		echo"<i class='alerts' style='color:red;font-size:15px;'><i class='fa fa-times'></i> File upload error! Please try again.</i>";
	}
	
?>



<script>
window.setTimeout(function () {
    $(".alerts").fadeTo(1000, 0).slideUp(0, function () {
        $(this).remove();
    });
}, 2000);
</script>