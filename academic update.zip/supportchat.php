<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>SupportChat</title>   
		 
       </head>
<body>	

<script type='text/javascript'>
    (function() {
    var s = document.createElement('script');s.type='text/javascript';s.async=true;s.id='lsInitScript';
    s.src='https://livesupporti.com/Scripts/clientAsync.js?acc=6bbfd8f5-f4ee-4428-af72-bddd78eaaf2f&skin=Air';
    var scr=document.getElementsByTagName('script')[0];scr.parentNode.appendChild(s, scr);
    })();
</script>
		
</body>
</html>


