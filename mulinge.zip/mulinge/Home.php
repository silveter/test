<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Homepage</title>   
		 <link rel="stylesheet" href="Home1.css">
		 <style>
table, th, td {
  border: 0px solid black;
}
</style>
       </head>
<body style="height:2000px;width:100%; margin-left: 0px;margin-right: 0px;margin-bottom: 0px;margin-top:0px;">	
<section id="links">
<div id="black-div">
                
                |<a href="#why-us">About us</a>|				
                <a href="#how-it-works">How it works</a>| 
				
               <a href="#pricing">Pricing</a>|
				
              <a href="#">Reviews</a>|
			  <a href="#">Contact us</a>
			 			 
			<button style="color: white;background-color:green; width:150px; height:35px;font-weight:bold;font-size:20px;border-radius:30px;" onclick="document.location = 'login.php'">Order Now</button>	
			
                  <div style="float: right;" id="profile">
				   <a href="sign_up.php" style="color:white; black;backgroud_color: white">Register</a>
                   <a href="login.php" style="color: black;">Log in</a>					 
                  </div>       

     </div>
</section>
<section style="background-color:#a3daff;height:700px;"id="animate">
 <!--<h2>Automatic Slideshow</h2><p>Change image every 2 seconds:</p> //-->

        <div class="slideshow-container">

            <div class="mySlides fade">
                <div class="numbertext">1 / 3</div>
               <!-- <img src="1.jpg" style="width:50%" style="height:50%">-->
				<img src="images/caption.jpg" height="400" width="700">
            </div>

            <div class="mySlides fade">
                <div class="numbertext">2 / 3</div>
                <!--<img src="2.jpg" style="width:50%" style="height:50%">-->
				<img src="images/caption1.jpg" height="400" width="700">
            </div>

            <div class="mySlides fade">
                <div class="numbertext">3 / 3</div>
                <!--<img src="3.jpg" style="width:50%" style="height:50%">-->
				<img src="images/caption2.jpg" height="400" width="700">
            </div>

        </div>
        <br>

        <div style="text-align:center">
            <span class="dot"></span> 
            <span class="dot"></span> 
            <span class="dot"></span> 
        </div>

        <script>
            var slideIndex = 0;
            showSlides();

            function showSlides() {
                var i;
                var slides = document.getElementsByClassName("mySlides");
                var dots = document.getElementsByClassName("dot");
                for (i = 0; i < slides.length; i++) {
                    slides[i].style.display = "none";
                }
                slideIndex++;
                if (slideIndex > slides.length) {
                    slideIndex = 1
                }
                for (i = 0; i < dots.length; i++) {
                    dots[i].className = dots[i].className.replace(" active", "");
                }
                slides[slideIndex - 1].style.display = "block";
                dots[slideIndex - 1].className += " active";
                setTimeout(showSlides, 2000); // Change image every 2 seconds
            }
        </script>
		</section>
		<section style="background-color:#FFFFFF;height:700px;"id="why-us">
We have editors who keenly proofread the papers to ensure all instructions are adhered to.<br>
A refund of 40% if the customer gets a failing grade from our services.
You can access the <br>Plagiarism report from our site.
We are available 24/7
Offer bonus services after a particular<br> number has been completed from the same client. 

		</section>
		<section style="background-color:#DEDEDE;height:700px;font-weight:bold;"id="core-values">
At our writing company EssayScorp, customer satisfaction is our <br>top priority. 
All our papers are written with strict conformity <br>with your needs and those of the professor.
We take keen <br>concern towards quality and plagiarism free work.

		</section>
<section style="background-color:#FCFCFC;height:700px;"id="pricing">
<p style="font-weight:none;text-align:center;font-size:40px;">EssayScorp Custom Essay Pricing<p>

<table style="width:80%;text-align:center;margin-left: 10%;">
  <tr style="color:#FF6347;font-size:30px;">
    <th>High School</th>
    <th>College</th>
	<th>University</th>
	<th>Masters</th>
	<th>Ph.D</th>
  </tr>
  <tr style="font-size:25px;">
    <td>$8</td>
	<td>$10</td>
	<td>$12</td>
	<td>$15</td>
	<td>$20</td>
  </tr>
</table>


</section>
		<section style="background-color:#c8a3ff;height:700px;"id="how-it-works">
Place order. <br>
Chat with us for more details.<br>
Make full or partila payment.<br>
Sit down and wait for your paper.<br>
Review and rate our services. 

		</section>
		<section style="background-color:beige;height:700px;"id="contact-us">
Place order. <br>
Chat with us for more details.<br>
Make full or partila payment.<br>
Sit down and wait for your paper.<br>
Review and rate our services. 

		</section>
<?php
include ('supportchat.php');
?>
		
</body>
</html>


