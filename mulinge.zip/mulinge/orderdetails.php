
 <?php
		  include('student_menu.php');
		  
?>
<!DOCTYPE html>
<html>
<head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Order Details</title>
        <link rel="stylesheet" href="orderdetails.css">

    
</head>
		
<body onload="tabpage(event, 'order-info')">
<div class="container">
<div class="tab">
  <button style="color: #5F9EA0;" class="tablinks" onclick="tabpage(event, 'order-info')" required>Order Information</button>
  <!--<button style="color: #5F9EA0;" class="tablinks" onclick="tabpage(event, 'order-info')">Order Information</button>-->
  <button style="color: #5F9EA0;" class="tablinks" onclick="tabpage(event, 'More-Details')" required>More Details</button>
 </div> 
  
<form action="orderdetails.php" method="POST" name="login-form">
<div id="order-info" class="tabcontent">
                            <label for="projecttitle">Project Title</label><input type="text" id="title" name="title" required>
                           <label for="doc_type">Paper Type</label>
							  <select id="doc_type" name="doc_type">
								<option value="Research Paper">Research Paper</option>
								<option value="Term Paper">Term Paper</option>
								<option value="Essay">Essay</option>
								<option value="Report">Report</option>
								<option value="Speech">Speech</option>
								<option value="Presentation">Presentation</option>
								<option value="Research Proposal">Research Proposal</option>
								<option value="Thesis">Thesis</option>
								<option value="Proofreading">Proofreading</option>
								<option value="Personal Statement">Personal Statement</option>
								<option value="Outline">Outline</option>
								<option value="literature Review">Literature Review</option>
							  </select>
							  
							   <label for="Subject_area">Subject Area</label>
							  <select id="sub_area" name="sub_area">
								<option value="Computer Science">Computer Science</option>
								<option value="Biology">Biology</option>
								<option value="Business">Business</option>
								<option value="Chemistry">Chemistry</option>
								<option value="Information Technology">Information Technology</option>
								<option value="Environmental Science">Environmental Science</option>
								<option value="Technology">Technology</option>
								<option value="Cultural Studies">Cultural Studies</option>
								<option value="English">English</option>
								<option value="English Literature">English Literature</option>
								<option value="Marketing">Marketing</option>
								<option value="Finance">Finance</option>
							  </select>
							<label for="order_deatails">Description</label><textarea rows="4" cols="50" id="description" name="description"></textarea>
							<input type="file" id="myfile" name="myfile" multiple>	
							<button style="background-color:#5F9EA0;color: black;font-weight:bold;height:30px; width:100px;font-size:20px;border-radius: 10px;" 
							name="next" type="submit" class="next_btn" onclick="tabpage(event, 'More-Details')">Next</button>							
</div>
 <div id="More-Details" class="tabcontent">
 <label for="pages">No of Pages</label></br><input type="number" id="pages" name="pages" step="0.5" required style="width: 100%; height:30px;"></br>
 <label for="Deadline">Deadline</label></br><input type="date" id="deadline" name="deadline" required style="width: 100%; height:30px;"></br>
 <label for="payment">Order Value</label></br><input type="text" id="payment" name="payment" required></br>
 <div class="row">                 
<button style="background-color:#5F9EA0;font-weight:bold;left: 50%;font-size: 16px;height:30px;margin-left:auto;display:block;margin-right:auto; width:120px;border-radius: 5px;"
name="order-submit" type="submit" class="success-btn">Submit</button>
</div> 
</div>	

</form> 

                                                     
                  
<div style="margin-bottom:30px;margin-top:10px;text-align:center;height:10px;min-width:80%;margin-right:auto;margin-left:auto;">
<?php 
include('scripts/orderdetailsScr.php');

 ?>

</div>
<script>
function tabpage(evt, pagename) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(pagename).style.display = "block";
  evt.currentTarget.className += " active";
}
</script>

<script>
  $(function () {
    $('#datetimepicker1').datetimepicker();
 });
</script>

</body>
</html>