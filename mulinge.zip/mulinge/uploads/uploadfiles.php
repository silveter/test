<!DOCTYPE HTML>
<html lang="en-US">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DMS- File Management/</title>
<link rel="stylesheet" href="dms.css">
<?php 
session_start();
if(!($_SESSION['newuser'])){	  
header("location:http:index.php");}else{
	$uid=$_SESSION['newuser'];	
include('scripts/connect.php');
include('scripts/refresh.php');
}?>

</head>


<body>

<div id="content">

<div>
	<h1 style="font-weight:bold;text-align:center;color:#fff;">WELCOME TO DOCUMENT MANAGEMENT SYSTEM
	<font style="float:right;font-size:14px;font-family:Segoe UI;color:#92e20f;">LOGGED IN AS: <?php echo $uid;?></font></h1>
</div>


			
<div id="mid-div">	


<div id="form-div" style="margin-top:-1%;width:80%;min-height:500px;">
		
<div class="topnav">
  <a class="active" href="uploadfiles.php">Upload files</a>
  <a href="myfiles.php">View my files</a>
  <a style="float:right;" href="logout.php">Logout</a>
</div>
	

<div id="form-div">		
<form id="login-part" action="uploadfiles.php" method="POST" name="login-form" enctype="multipart/form-data">
<div style="text-align:center;font-family:Segoe UI;">
<h3 style="color:#100ba8;font-family:Segoe UI;font-weight:bold;">Please select file to upload:</h3>
</div>
<div class="form-input">
<label  class="form-label" >File: </label>
<input class="form-field" type="file" name="filename" required>
</div>
<div class="form-input" style="text-align:right;">
<button type="reset" style="margin-right:5%;" class="warning-btn">Clear file</button>
<button name="upload-file" type="submit" style="margin-right:10%;" class="success-btn">Upload file</button>
</div>
</form>	

<div style="text-align:center;font-family:Segoe UI;margin-top:-30px;">
<?php include('scripts/fileUploadScr.php'); ?>
</div>

</div>	


</div>	


</div>	


</div>
</body>
</html>































