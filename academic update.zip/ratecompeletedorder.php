<?php
include 'functions.php';
include 'student_menu.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Order Payment</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
	
<?php
		
		//fetch products from the database
		$results = $conn->query("SELECT * FROM orderdetails WHERE orderid='".$_GET['id']."'");
		$row = $results->fetch_assoc();
		
	?>
 <fieldset style="background-color:beige;float:right;width:300px;height:300px;margin-top:-270px;margin-bottom:0px;margin-right: 0px;"> 
 <?php
 include ('rating/ratings.php');
 ?>

 </fieldset> 
   
<table style="margin-bottom:20px;margin-top:-250px;margin-left: 16%;text-align:left;" width="800" border="1" cellpadding="1" cellspacing='1' bgcolor='beige'>

        <tr bgcolor="#beebeb">
                     
                     <th>Assignment Description</th>
					
                     
           </tr>
		   
<?php


if (mysqli_num_rows($results) > 0) {
 echo "<tr>"
    . "<td>".$row["description"]."</td>";
"</tr>";


    
} else {
    echo "0 results";
}

mysqli_close($conn);
?>


      
	 <form id="login-part" action="payment.php" method="POST" name="login-form" enctype="multipart/form-data">

        

        </table>
		<div style="float: right;margin-right:-13%;transform: translateY(-200%);"class="row">
		 
		 
           </div>
          
    </form>
    
</body>
</html>
