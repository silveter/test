<?php
include('functions.php');
include('menu.php'); 
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration system PHP and MySQL</title>
	<style>
	hr.new1 {
  border-top: 3px dashed orange;
}
	</style>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">  
</head>
<link rel="stylesheet" href="style.css">
<body>
	<!--<div style="text-align: center;" id="header">
		<h2>Login</h2>
	</div>-->
	<form style="margin-top:10px;" method="post" action="login.php">

		<?php echo display_error(); ?>
		<h2 style="color:orange;">Log in</h2>
<!--<div style="text-align:left;margin-left: 10px;margin-top: 20px;"id="contact"><i class="fa fa-facebook-square fa-5x"></i>  
<div style="text-align:left;margin-left: 10px;margin-top: 20px;"id="contact"><i class="fa fa-google-plus-square" aria-hidden="true"></i>-->
<hr class="new1">
</div>

		<div class="input-group">
			<label>Username</label>
			<input type="text" name="username" >
		</div>
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password">
		</div>
		<div class="input-group">
			<button style="margin-left:80px;" type="submit" class="btn" name="login_btn">Login</button>
			Not yet a member? <a href="sign_up.php" style="color:blue;font-size: 18px;">Sign up</a>
		</div>
		
	</form>
</body>
</html>