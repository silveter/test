<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>profile</title>
           
        </head>
		
<body>
<img style="width:100px;float:left;margin-left:10px;margin-top:10px;"src="profile.jpg" alt="Italian Trulli"class="image">
<div style="color:black;font-weight:bold;margin-left:1%;margin-top:100px;"class="left-down">
<br>
<br>Orders in progress
				
				<font style="color=white">
				
				<?php 
				include_once('functions.php');
				echo mysqli_num_rows($conn->query("SELECT * from orderdetails WHERE assigned='Y' and completed='Y'"));
				//echo $results;
				?>
				</font></br>
<br>Orders in Revisions</br>
<br>Orders Completed
<font style="color=white">
				
				<?php 
				include_once('functions.php');
				echo mysqli_num_rows($conn->query("SELECT * from orderdetails WHERE assigned='Y' and returned='Y'"));
				//echo $results;
				?>
				</font></br>
<br>Orders Cancelled</br>
</div>
</body>
</html>