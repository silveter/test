<?php 
include('functions.php'); 
include('menu.php') ;
?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration system PHP and MySQL</title>
	<style>
	hr.new1 {
  border-top: 3px dashed orange;
}
	</style>
</head>
<link rel="stylesheet" href="style.css">
<body>
<!--<div style="text-align: center;" id="header">
	<h2 style="color:pink;">Fill Form to Register</h2>
</div>-->
<form style="margin-top:10px;padding-bottom: 0px;" method="post" action="sign_up.php">
<?php echo display_error(); ?>
<h2 style="color:orange;">Sign up</h2>
<div style="text-align:left;margin-left: 10px;margin-top: 20px;"id="contact"> 
<!--<a href="https://www.facebook.com/" target="_blank"><img src="facebook_login.png" style="width:140px;height:50px;"/></a>
<a href="https://myaccount.google.com/" target="_blank"><img src="google_login.png" style="width:140px;height:50px;"/></a>
<a href="https://twitter.com/hashtag/login" target="_blank"><img src="twitter_login.png" style="width:140px;height:50px;"/></a>-->

<hr class="new1">
</div>
	<div class="input-group">
		<label>Username</label>
		<input type="text" name="username" value="">
	</div>
	<div class="input-group">
		<label>Email</label>
		<input type="email" name="email" value="">
	</div>
	<div class="input-group">
		<label>Password</label>
		<input type="password" name="password_1">
	</div>
	<div class="input-group">
		<label>Confirm password</label>
		<input type="password" name="password_2">
	</div>
	<div class="input-group">
		<button style="margin-left:80px;"type="submit" class="btn" name="register_btn">Register</button>
		Already a member? <a href="login.php" style="color:blue;font-size: 18px;">Sign in</a>
	</div>
	<p>
		
	</p>
</form>
</body>
</html>