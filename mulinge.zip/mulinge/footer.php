<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  height:50px;
  align:center;
  background-color: #c6c5c0;
  color: black;
  text-align: center;
 font-size: 12px;
}
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<div class="footer">
      
 <img style="width: 200px;height:25px;margin-top: 20px;margin-left:150px;"src="pay.png" alt="Italian Trulli"class="image">
 <!--<i class="fa fa-cc-paypal" style="font-size:44px;height:40px; color: blue;"></i>-->
</div>
</body>
</html>
