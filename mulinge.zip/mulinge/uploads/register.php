<!DOCTYPE HTML>
<html lang="en-US">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DMS- User Registration/</title>
<link rel="stylesheet" href="dms.css">
</head>
<body>

<div id="content">

<div>
	<h1 style="font-weight:bold;text-align:center;color:#fff;">WELCOME TO DOCUMENT MANAGEMENT SYSTEM</h1>
</div>


			
<div id="mid-div">	
	
<div id="form-div" style="margin-top:0%;width:55%;">		
<form action="register.php" method="POST" name="login-form">
<div style="text-align:center;">
<h2 style="color:#100ba8;font-family:Segoe UI;font-weight:bold;">Please fill in the details below to Register</h2>
</div>
<div class="form-input">
<label  class="form-label" >First Name: </label>
<input class="form-field" type="text" required name="fn" placeholder="First Name"
onkeyup='var start = this.selectionStart; var end = this.selectionEnd; this.value = this.value.toUpperCase(); this.setSelectionRange(start, end);'/>
</div>

<div class="form-input">
<label  class="form-label" >Other Names: </label>
<input class="form-field" type="text" required name="ons" placeholder="Other Names"
onkeyup='var start = this.selectionStart; var end = this.selectionEnd; this.value = this.value.toUpperCase(); this.setSelectionRange(start, end);'/>
</div>


<div class="form-input">
<label  class="form-label" >Phone no.: </label>
<input  class="form-field" required name="phone" type="number" placeholder="7XXXXXXXX or 07XXXXXXXX">
</div>


<div class="form-input">
<label  class="form-label" >Username: </label>
<input class="form-field" type="text" required name="un" placeholder="Username"
onkeyup='var start = this.selectionStart; var end = this.selectionEnd; this.value = this.value.toUpperCase(); this.setSelectionRange(start, end);'/>
</div>

<div class="form-input">
<label  class="form-label" >Password: </label>
<input  class="form-field" required name="pwd" type="password" placeholder="Password">
</div>




<div class="form-input" style="text-align:right;">
<button type="reset" style="margin-right:5%;" class="warning-btn">Clear</button>
<button name="register" type="submit" style="margin-right:10%;" class="success-btn">Submit</button>
</div>



</form>	
<div style="margin-bottom:20px;margin-top:-20px;text-align:center;height:10px;min-width:80%;margin-right:auto;margin-left:auto;">
<?php include('scripts/registerScr.php'); ?>

</div>

<div style="text-align:center;font-family:Segoe UI;">
<h4>Already Registered? Click 
<a href="index.php">here</a> to login.</h4>
</div>
</div>	


</div>	


</div>
</body>
</html>































