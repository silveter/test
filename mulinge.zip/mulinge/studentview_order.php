<?php
include 'functions.php';
include 'student_menu.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Order Payment</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
	
<?php
		
		//fetch products from the database
		$results = $conn->query("SELECT * FROM orderdetails WHERE orderid='".$_GET['id']."'");
		$row = $results->fetch_assoc();
		
	?>
 <fieldset style="background-color:beige;float:right;width:300px;height:480px;margin-top:-288px;margin-bottom:0px;margin-right: 0px;"> 
<div style="float:right;text-align:left;font-family:Segoe UI;transform: translateY(100%);font-weight:bold;margin-right:25%;">
Order Id: <?php echo $_GET['id']; ?>
</div>

<div style="float:right;font-family:Segoe UI;transform: translateY(250%);color: green;font-weight:bold;margin-right:10%;">
Deadline:<?php echo $row['deadline']; ?>
 </div> 
 <div style="float:right;font-family:Segoe UI;transform: translateY(550%);color: green;font-weight:bold;margin-right:-35%;">
Amount $:<?php echo $row['price']; ?>
 </div> 
 </fieldset> 
   
<table style="margin-bottom:20px;margin-top:-250px;margin-left: 13%;text-align:left;" width="800" border="1" cellpadding="1" cellspacing='1' bgcolor='beige'>

        <tr bgcolor="#beebeb">
                     
                     <th>Assignment Description</th>
					
                     
           </tr>
		   
<?php


if (mysqli_num_rows($results) > 0) {
 echo "<tr>"
    . "<td>".$row["description"]."</td>";
"</tr>";


    
} else {
    echo "0 results";
}

mysqli_close($conn);
?>


      
	 <form id="login-part" action="payment.php" method="POST" name="login-form" enctype="multipart/form-data">

        

        </table>
		<div style="float: right;margin-right:-13%;transform: translateY(-200%);"class="row">
		 
		 <input type="hidden" value="<?php echo $_GET['id'];?>" name="pay_id"/> 
		 <button style="background-color:silver;font-weight:bold;font-size: 20px;height:30px;display:block;width:200px;transform: translateY(50%);
		 margin-right:-120px;  border-radius: 10px; color: white"name="order-submit" type="submit" class="pick_btn">
		 <i class="fa fa-check-square-o" style="font-size:20px;color:green"></i>Payment</button>
					
           </div>
          
    </form>
    
</body>
</html>
