<?php
require_once('functions.php');
require_once('admin_menu.php');

if (isset($_POST['uploadBtn']) && $_POST['uploadBtn'] == 'Upload') {
    if (isset($_FILES['uploadedFile']) && $_FILES['uploadedFile']['error'] === UPLOAD_ERR_OK){
        
        if(isset($_POST['gender'])){
            
        //get gender and age
        $gender = mysqli_real_escape_string($conn, $_POST['gender']);
        if(isset($_POST['age'])){
            $age = mysqli_real_escape_string($conn, $_POST['age']);
        }
        else{
            $age=0;
        }
        
            // get details of the uploaded file
        $fileTmpPath = $_FILES['uploadedFile']['tmp_name'];
        $fileName = $_FILES['uploadedFile']['name'];
        $fileSize = $_FILES['uploadedFile']['size'];
        $fileType = $_FILES['uploadedFile']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));
        
        
        $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
        $allowedfileExtensions = array('jpg', 'gif', 'png', 'zip', 'txt', 'xls', 'doc', 'pdf', 'docx');
        if (in_array($fileExtension, $allowedfileExtensions)) {
            // directory in which the uploaded file will be moved
            $uploadFileDir = './uploaded_files/';
            $dest_path = $uploadFileDir . $newFileName;

            if(move_uploaded_file($fileTmpPath, $dest_path))
            {
                $query = "INSERT INTO fileupload (gender, age_over_18) VALUES ('$gender', '$age')";
				$result = $conn->query("update orderdetails set returned='Y' WHERE orderid='".$_POST['upload_id']."'");
                if ($conn->query($query) === TRUE) {
                      $message ='Solution uploaded';
                         echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                          <strong>';
                          echo $message;
                         echo'</strong>
                          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                         </div>';
                        
                   }else{
                        $message ='File is successfully uploaded but error occured while saving the file';
                        echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong>';
                        echo $message;
                        echo'</strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        </div>';
                   }
            }
            else
            {
              $message = 'There was some error moving the file to upload directory. Please make sure the upload directory is writable by web server.';
             echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
              <strong>';
              echo $message;
             echo'</strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>';
             
            }
        
        }else{
            $message ='File Type not supported';
           echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
              <strong>';
              echo $message;
             echo'</strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>';
            
             
        }
        }else{
           echo '
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
          <strong>Select your gender category</strong>.
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        
        ';  
        }
    }else{
        echo '
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
          <strong>Select File to upload</strong>.
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        
        ';
    }
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/styles.css">
</head>
<body>
<table style="transform: translateY(-280%); margin-left: 13%;" width="800" border="1" cellpadding="1" cellspacing='1' bgcolor='beige'>

        <tr bgcolor="#00BFFF";>
                     
                     <th>Order Description</th>
					
                     
         </tr> 
<div class="container">
 
   <div class="row">
   <div class="col-md-6">
   <?php

$sql = "SELECT * FROM orderdetails WHERE orderid='".$_GET['id']."'";
$result = mysqli_query($conn, $sql);



if (mysqli_num_rows($result) >0) 

{
    // output data of each row
while ($row = mysqli_fetch_assoc($result)) 

//($row = mysqli_fetch_assoc($result)) 
{
 echo "<tr>"
   
	. "<td>".$row["description"]."</td>";
	
"</tr>";
    }
    
} else {
    echo "";
}

mysqli_close($conn);
?>

<fieldset style="background-color: beige; float:right;margin-right:0%; width:330px; height: 500px; margin-top:-278px;">
<div style="text-align:right;font-family:Segoe UI;color: black;font-weight:bold;margin-right:70%;transform: translateY(50%);">
<?php echo $row['orderid']; ?>
</div>
<div style="text-align:right;font-family:Segoe UI;color: black;font-weight:bold;margin-right:70%;transform: translateY(200%);">
<?php echo $row['deadline']; ?>
</div>
<div style="text-align:right;font-family:Segoe UI;color: black;font-weight:bold;margin-right:90%;transform: translateY(350%);">
<!--<i class="fa fa-dollar" style="font-size:20px;color:red"></i>--><?php echo $row['price']; 
  ?>
</div>
<div class="text-center mt-5">

<button style="float: right;background-color:black;margin-right:30%; transform: translateY(250%);font-weight:bold;color:white;" type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#gender_and_age_modal">
<i class="fa fa-upload" style="font-size:20px;color:white"></i>Final Solution</button>

</div>
</fieldset>
   </div>
   </div>
   </table>
<!-- Modal -->
<div class="modal fade" id="gender_and_age_modal" tabindex="-1" role="dialog" aria-labelledby="gender_and_age_modalTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="gender_and_age_modalTitle">Select details to continue</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
       <form action="" method="post" enctype="multipart/form-data">
      <div class="modal-body">
      <div class="custom-control custom-checkbox">
        <input type="checkbox" name="gender" value="Male" class="custom-control-input" id="male">
        <label class="custom-control-label" for="male">All instructions in the order description, files, and messages are followed</label>
      </div>

      <div class="custom-control custom-checkbox">
        <input type="checkbox" name="gender" value="Female" class="custom-control-input" id="female">
        <label class="custom-control-label" for="female">All formatting and styles are implemented</label>
      </div>
 
      <div class="custom-control custom-checkbox">
        <input type="checkbox" name="age" value="1" class="custom-control-input" id="age">
        <label class="custom-control-label" for="age">Number of sources have been used</label>
      </div>
      <br>
      <!-- order detils     -->
        Select file to upload: <br>
        <input type="file" name="uploadedFile" id="uploadedFile" class="btn btn-outline-info"> <br><br>
       
    
    </div>
      <div class="modal-footer">
	   <input type='hidden' value="<?php echo $_GET['id'];?>" name="upload_id"/> 
        <input type="submit" value="Upload Files" name="uploadBtn" class="btn btn-info "><br>
      </div>
      </form>
    </div>
  </div>
</div>
</div>


 <!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script src="js/script.js"></script>
</body>
</html>

