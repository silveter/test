-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2020 at 06:40 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.0.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `academic`
--

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `FileID` int(10) NOT NULL,
  `FileName` varchar(50) NOT NULL,
  `FileType` varchar(50) NOT NULL,
  `FileSize` int(100) NOT NULL,
  `SourceLocation` varchar(100) NOT NULL,
  `UploadLocation` varchar(100) NOT NULL,
  `UploadUser` varchar(20) NOT NULL,
  `SharedState` char(1) NOT NULL DEFAULT 'N',
  `SharedBy` varchar(20) NOT NULL DEFAULT 'NONE',
  `SharedTo` varchar(20) NOT NULL DEFAULT 'NONE',
  `ShareDateTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `UploadDateTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`FileID`, `FileName`, `FileType`, `FileSize`, `SourceLocation`, `UploadLocation`, `UploadUser`, `SharedState`, `SharedBy`, `SharedTo`, `ShareDateTime`, `UploadDateTime`) VALUES
(0, 'dms.sql', 'application/octet-stream', 1898, 'C:xampp	mpphpC82A.tmp', 'uploads/dms.sql', '', 'N', 'NONE', 'NONE', '0000-00-00 00:00:00', '2020-05-06 09:56:30'),
(0, 'dms.css', 'text/css', 1987, 'C:xampp	mpphpD2D5.tmp', 'uploads/dms.css', '', 'N', 'NONE', 'NONE', '0000-00-00 00:00:00', '2020-05-06 09:57:38'),
(0, 'index.php', 'application/octet-stream', 1942, 'C:xampp	mpphp3DD5.tmp', 'uploads/index.php', '', 'N', 'NONE', 'NONE', '0000-00-00 00:00:00', '2020-05-06 09:58:05'),
(0, 'uploadfiles.php', 'application/octet-stream', 1952, 'C:xampp	mpphp9B09.tmp', 'uploads/uploadfiles.php', '', 'N', 'NONE', 'NONE', '0000-00-00 00:00:00', '2020-05-06 09:58:29'),
(0, 'register.php', 'application/octet-stream', 2693, 'C:xampp	mpphp57E2.tmp', 'uploads/register.php', '', 'N', 'NONE', 'NONE', '0000-00-00 00:00:00', '2020-05-06 09:59:18');

-- --------------------------------------------------------

--
-- Table structure for table `fileupload`
--

CREATE TABLE `fileupload` (
  `id` int(11) NOT NULL,
  `gender` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `age_over_18` tinyint(1) NOT NULL DEFAULT '0',
  `file_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `date_uploaded` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fileupload`
--

INSERT INTO `fileupload` (`id`, `gender`, `age_over_18`, `file_url`, `date_uploaded`) VALUES
(45, 'Male', 1, '', '2020-04-11 03:43:22'),
(46, 'Male', 1, '', '2020-04-16 10:14:25'),
(47, 'Female', 1, '', '2020-05-06 00:04:18');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `orderid` int(11) NOT NULL,
  `title` varchar(5000) NOT NULL,
  `doc_type` varchar(5000) NOT NULL,
  `sub_area` varchar(5000) NOT NULL,
  `pages` int(11) NOT NULL,
  `deadline` date NOT NULL,
  `description` text NOT NULL,
  `price` float NOT NULL,
  `assigned` char(1) NOT NULL,
  `completed` char(1) NOT NULL,
  `returned` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`orderid`, `title`, `doc_type`, `sub_area`, `pages`, `deadline`, `description`, `price`, `assigned`, `completed`, `returned`) VALUES
(43992, 'Business studies', 'Research Paper', 'Business', 5, '2020-04-24', 'Roughly defined, business management refers to the activities and responsibilities associated with running an organisation, which may include planning, implementation, controlling, monitoring, organising, optimising, delegating and so on.', 50, 'Y', '', ''),
(25212, 'Database administration ', 'Research Paper', 'Computer Science', 4, '2020-05-05', 'Each application is different but the key is to identify key services that may be a bottleneck and the first ones to cripple under increased load pressure. One of the most common bottlenecks can be the database.\r\nThe database is used to store data in an application. You may use a traditional relational database such as MySQL or a NoSQL database such as MongoDB. In simple terms, the database is used to write data (save it) and read it (view it). The database can often be one of the first components to fall down under high load pressure in an application environment.', 40, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `user_type` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `email`, `user_type`, `password`) VALUES
('silvester', 'silvesterkisalu@gmail.com', 'Admin', 'bbe1a1cb628db131f392669d1b84f475'),
('MUTINDA', 'mutinda@gmail.com', 'user', 'fcf174df86a81fd029f46c8bafcd15ff'),
('musembi', 'musembi@gmail.com', 'user', '2d468f5768601e4962f8882bdc97b249');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fileupload`
--
ALTER TABLE `fileupload`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fileupload`
--
ALTER TABLE `fileupload`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
