<?php
		include ('menu.php');
?>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Homepage</title>   
        </head>
<body style="height: 2000px;">	

<!--<img style="width:400px;float:right;margin-right:30px;margin-top:10px;"src="student.jpg" alt="Italian Trulli"class="image">
	  
	   <p class="blink"><img style="width:300px;margin-top:-40px;"src="satify.png" alt="Italian Trulli"class="blink-image"></p>-->
	   	  
	  
</body>
</html>


