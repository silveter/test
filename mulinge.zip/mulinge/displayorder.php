<!DOCTYPE html>
<html>
    <head>
        <title> Order Page</title>
    </head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

</style>
    <body>
<!--<form class="report-form" action="report.php" method="GET">-->
<table style="margin-bottom:20px;margin-top:-250px; margin-left: 13%;" width="800" border="1" cellpadding="1" cellspacing='1'>

        <tr bgcolor="#00BFFF">
                     
                 
					 <th>Subject</th>
					 <th>Type of Paper</th>
					 <th>Order Id </th>
					
                     
           </tr>
        

           
<?php
include_once('admin_menu.php');
include_once ('functions.php');
$sql = "select * from orderdetails where assigned=''";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result)>0) 

{
    // output data of each row
while ($row = mysqli_fetch_assoc($result)) 

//($row = mysqli_fetch_assoc($result)) 
{
 echo "<tr>"
   	. "<td>".$row["sub_area"]."</td>"
	. "<td>".$row["doc_type"]."</td>";
	
echo '<td><a href="pickorder.php?id=' . $row["orderid"].'">' . $row["orderid"].'</a></td>';
"</tr>";
    }
    
} else {
    echo "";
}

mysqli_close($conn);
?> 
          
          
           </table>


   </body>

</html>