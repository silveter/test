<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="submitorder.css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Expert upload</title>

</head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 70%; /* Full width */
  height: 50%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  position: relative;
  background-color: #fefefe;
  margin: auto;
  padding: 0;
  border: 1px solid #888;
  width: 80%;
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
  -webkit-animation-name: animatetop;
  -webkit-animation-duration: 0.4s;
  animation-name: animatetop;
  animation-duration: 0.4s
}

/* Add Animation */
@-webkit-keyframes animatetop {
  from {top:-300px; opacity:0} 
  to {top:0; opacity:1}
}

@keyframes animatetop {
  from {top:-300px; opacity:0}
  to {top:0; opacity:1}
}

/* The Close Button */
.close {
  color: white;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

.modal-header {
  padding: 2px 16px;
  background-color: #b4d3b2;
  color: white;
}

.modal-body {padding: 2px 16px;}

</style>
<body> 
   
	<table align="center" panding-right width="800" border="0" cellpadding="1" cellspacing='1' bgcolor='white'>

        <tr bgcolor="#beebeb";>
                     
                     <th>Order Description</th>
					
                     
         </tr>
		   
<?php
include_once('functions.php');
include_once('admin_menu.php');

//$sql = "select * from orderdetails where order_status=''";
$sql = "SELECT description FROM orderdetails WHERE orderid='".$_GET['id']."'";
$result = mysqli_query($conn, $sql);



if (mysqli_num_rows($result) >0) 

{
    // output data of each row
while ($row = mysqli_fetch_assoc($result)) 

//($row = mysqli_fetch_assoc($result)) 
{
 echo "<tr>"
   
	. "<td>".$row["description"]."</td>";
	
"</tr>";
    }
    
} else {
    echo "";
}

mysqli_close($conn);
?>

<!-- Trigger/Open The Modal -->
<div style="text-align:center;font-family:Segoe UI; position: absolute;left: 550px;top: 300px;">
<button id="myBtn">Upload Solution</button>
</div>

<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <div class="modal-header">
      <span class="close">&times;</span>
      <h2>Upload Solution</h2>
    </div>
<div class="modal-body">
<div id="form-div">		
<form id="login-part" action="solutionupload.php" method="POST" name="login-form" enctype="multipart/form-data">

<div class="form-input">
<input class="form-field" type="file" name="filename" required>
</div>
<!--<div class="form-input" style="text-align:right;">-->
<div class="row">
<button name="upload-file" type="submit" style="margin-right:30%;background: #5F9EA0;font-weight:bold;" class="success-btn">Submit Solution</button>
</div>
</form>	

<div style="text-align:center;font-family:Segoe UI;margin-top:-30px;">
<?php include('scripts/submitOrderScr.php'); ?>
</div>

</div>	

</div>
    
  </div>

</div>

<script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
</table>

<!--<form id="login-part" action="uploadmodal.php" method="POST" name="login-form" enctype="multipart/form-data">
 </table>
<div class="row">
<button style="background-color:silver;font-weight:bold;left: 50%;font-size: 20px;height:30px;margin-left:auto;display:block;margin-right:auto; 
width:150px;"name="order-submit" type="submit" class="pick_btn">Upload Order</button>
					
</div>
          
</form>  -->
</body>
</html>
