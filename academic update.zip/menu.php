<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title></title>
        <link rel="stylesheet" href="Home.css">
		
        </head>
		<style>
   
    </style>
        <body>
     <div id="black-div">
                
                |<a href="index.php">About us</a>|				
                <a href="#tag_a.asp">How it works</a>| 
				
               <a href="#test.php">Pricing</a>|
				
              <a href="#">Reviews</a>|
			  <a href="#">Contact us</a>
			 			 
                  <div style="float: right;" id="profile">
				   <a href="sign_up.php" style="color:black;">Register</a>
                   <a href="login.php" style="color: black;">Log in</a>					 
                  </div>       

     </div>
	  
	
   </body>
</html>