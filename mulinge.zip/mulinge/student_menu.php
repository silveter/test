<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title></title>
        <link rel="stylesheet" href="student_menu.css">
		<style>
		.vl {
  border-left: 8px solid #A9A9A9;
  height: 100%;
  position: absolute;
  left: 12%;
  margin-top: 0px;
}
		</style>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        </head>
        <body>


<div id="black-div">
                <hr class="new1">
				<!---EssaysCorp--name of the company-->
				|<a href="student_orders.php">Home</a>|					
				<a href="student_orders.php">My Orders( 
								<font style="color=white">
				
				<?php 
				include_once('functions.php');
				echo mysqli_num_rows($conn->query("SELECT * from orderdetails WHERE assigned=''"));
				//echo $results;
				?>
				</font>)</a>|
				<a href="returnedorders.php">Returned
				( 
								<font style="color=white">
				
				<?php 
				include_once('functions.php');
				echo mysqli_num_rows($conn->query("SELECT * from orderdetails WHERE returned='Y'"));
				//echo $results;
				?>
				</font>)</a>|    
				<a href="#test.php">Rate Expert</a>|             
				<a href="orderdetails.php">Place Project</a>| 
											
                <a href="#orderdetails.php"><i class="fa fa-envelope-o" style="font-size:20px"></i></a>| 	
				
<div class="dropdown">
<button class="dropbtn"><img style="width:35px;float:right;margin-right:30px;margin-top:10px;"src="profileup.jpg" alt="Italian Trulli"class="image"> 
<i class="fa fa-caret-down"></i>
</button>
<div class="dropdown-content">
                        			
<a href="login.php?logout='1'" style="color: black;">Change Password</a>
<a href="login.php?logout='1'" style="color: black;">Log Out</a>
</div>
 </div>
</div>
<div class="vl"></div>  			

<?php
include('profile.php');
?>			
<?php
		include ('footer.php');
?>
        </body>
    </html>
	

