<!DOCTYPE HTML>
<html lang="en-US">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DMS - User Login/</title>
<link rel="stylesheet" href="dms.css">
</head>
<body>

<div id="content">

<div>
	<h1 style="font-weight:bold;text-align:center;color:#fff;">WELCOME TO DOCUMENT MANAGEMENT SYSTEM</h1>
</div>


			
<div id="mid-div">	
	
<div id="form-div">		
<form id="login-part" action="index.php" method="POST" name="login-form">
<div style="text-align:center;">
<h3 style="color:#100ba8;font-family:Segoe UI;font-weight:bold;">Please login to proceed</h3>
</div>
<div class="form-input">
<label  class="form-label" >Username: </label>
<input class="form-field" type="text" required name="login-username" placeholder="Username"
onkeyup='var start = this.selectionStart; var end = this.selectionEnd; this.value = this.value.toUpperCase(); this.setSelectionRange(start, end);'/>
</div>

<div class="form-input">
<label  class="form-label" >Password: </label>
<input  class="form-field" required name="login-password" type="password">
</div>


<div class="form-input" style="text-align:right;">
<button type="reset" style="margin-right:5%;" class="warning-btn">Clear</button>
<button name="login-submit" type="submit" style="margin-right:10%;" class="success-btn">Login</button>
</div>


</form>	

<div style="text-align:center;font-family:Segoe UI;margin-top:-30px;">
<?php include('scripts/loginScr.php'); ?>
</div>

<div style="text-align:center;font-family:Segoe UI;margin-top:-10px;">
<p>Forgot password? Click 
<a href="recpwd.php">here</a> to recover your password.</p>
</div>



<div style="text-align:center;font-family:Segoe UI;margin-top:-10px;">
<h4>Not Registered? Click 
<a href="register.php">here</a> to register.</h4>
</div>
</div>	


</div>	


</div>
</body>
</html>































