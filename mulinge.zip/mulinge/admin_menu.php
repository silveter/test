<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title></title>
        <link rel="stylesheet" href="admin_menu.css">
    <style>
		.vl {
  border-left: 8px solid #A9A9A9;
  height: 100%;
  position: absolute;
  left: 14%;
  margin-top: 0px;
  margin-bottom:0px;
  
}
a.link-btn {
        color: #fff;
        background: #00BFFF;
        display:inline-block;
               
        font: bold 14px Arial, sans-serif;
        text-decoration: none;
      
        padding: 6px 20px;
	   transform: translateY(2%);
    }
    
		</style>
        </head>
        <body>


            <div id="black-div">
               
                |<a href="admin_menu.php">Dashboard</a>|				
                <a href="displayorder.php">New Orders ( 
								<font style="color=white">
				
				<?php 
				include_once('functions.php');
				echo mysqli_num_rows($conn->query("SELECT * from orderdetails WHERE assigned=''"));
				//echo $results;
				?>
				</font>)</a>|
                <a href="confirmed.php">Orders Confirmed (
				
				<font style="color=white">
				
				<?php 
				include_once('functions.php');
				echo mysqli_num_rows($conn->query("SELECT * from orderdetails WHERE assigned='Y' and returned='' and completed=''"));
				//echo $results;
				?>
				</font>)
				</a>|              
				<a href="uploadfiles.php">Upload Samples</a>|
                <a href="#">Students</a>|
				
				<div class="dropdown">
					<button class="dropbtn"><img style="width:35px;float:right;margin-right:50px;margin-top:60px;"src="profileup.jpg" alt="Italian Trulli"class="image"> 
					<i class="fa fa-caret-down"></i>
					</button>
					<div class="dropdown-content">
														
					<a href="login.php?logout='1'" style="color: black;">Change Password</a>
					<a href="login.php?logout='1'" style="color: black;">Log Out</a>
					</div>
				</div>
</div>
			
			<div class="vl"></div> 
<div style="border-left: 8px solid #A9A9A9; height: 100%; position: absolute;right: 24%;margin-top: 0px; margin-bottom:0px;" id="v2"></div> 			

<?php
include('profile.php');
include('admin_footer.php');
?>

</body>
</html>