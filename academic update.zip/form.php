<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Essay Corp | Order Form</title>
  
  <!--Bootsrap-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	
	<!--countries codes and flags-->	
	<script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
	<script src="js/jquery.ccpicker.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="css/jquery.ccpicker.css">

</head>
<body style="background:#937D14;">
<div class="wrapper" style="margin-top:20px;margin-bottom:20px;">

 
  <div class="content-wrapper">
  
  
    <section class="content">
      <div class="container">
        <div class="row"  style="background:#eeefff;padding-bottom:10px;">
		
		  
            <div class="primary">
			
			  
              <form role="form" id="orderForm" method="post" action="post.php" enctype="multipart/form-data">
                <div class="form-body">
				
				
          <div class="col-md-12" style="background:#004f49;color:#fff; margin-bottom:10px;">
		  <h3 style="font-weight:bold;">Order Form</h3>
		  </div>
		  
          <div class="col-md-6">
				
                  <div class="form-group">
                    <label>First Name</label>
                    <input type="text" required class="form-control" name="first_name" placeholder="Enter First Name">
                  </div>
				  
                  <div class="form-group">
                    <label>Other Names</label>
                    <input type="text" required class="form-control" name="other_names" placeholder="Enter Other Names">
                  </div>
				  
                  <div class="form-group">
                    <label>Email</label>
                    <input type="email" class="form-control" name="email" placeholder="Enter Email">
                  </div>
				  
				  <div class="form-group">
                    <label>Phone Number</label>					
					
					<div class="input">					
						<input type="text" id="phoneField1"  class="form-control" name="phone_num" placeholder="Phone number" style="width:85%;float:right;"/>
						
						
					</div>					
                  </div>
				  
				  
				  
                  <div class="form-group">
                    <label>Country</label>
					
						<input type="text" disabled id="phoneField2"  class="form-control" placeholder="Populated from country code above"/>
						<input type="text"  hidden id="counrtyField" name="country_name"/>
						<input type="text"  hidden id="phoneCodeField" name="country_code"/>
                  </div>
				  
				  
				  
                  <div class="form-group">
                    <label>Project Title</label>
                    <input type="text" class="form-control" name="proj_title" placeholder="Enter Project Title">
                  </div>
				  
				  
                  <div class="form-group">
                    <label>Paper Type</label>					
					<select id="doc_type" class="form-control" name="doc_type">
						<option value="Research Paper">Research Paper</option>
						<option value="Term Paper">Term Paper</option>
						<option value="Essay">Essay</option>
						<option value="Report">Report</option>
						<option value="Speech">Speech</option>
						<option value="Presentation">Presentation</option>
						<option value="Research Proposal">Research Proposal</option>
						<option value="Thesis">Thesis</option>
						<option value="Proofreading">Proofreading</option>
						<option value="Personal Statement">Personal Statement</option>
						<option value="Outline">Outline</option>
						<option value="literature Review">Literature Review</option>
					</select>				
                  </div>





			
                  <div class="form-group">
                    <label>Subject Area</label>					
					<select class="form-control" id="sub_area" name="sub_area">
						<option value="Computer Science">Computer Science</option>
						<option value="Biology">Biology</option>
						<option value="Business">Business</option>
						<option value="Chemistry">Chemistry</option>
						<option value="Information Technology">Information Technology</option>
						<option value="Environmental Science">Environmental Science</option>
						<option value="Technology">Technology</option>
						<option value="Cultural Studies">Cultural Studies</option>
						<option value="English">English</option>
						<option value="English Literature">English Literature</option>
						<option value="Marketing">Marketing</option>
						<option value="Finance">Finance</option>
					</select>			
                  </div> 
				  			
				  
				  
				  
				  
			</div>

			<div class="col-md-6">
			
			

                  
                  <div class="form-group">
                    <label>Deadline</label>					
                    <input type="datetime-local" required class="form-control" id="deadline" name="deadline"  oninput="calculateTot();" >
                  </div>
				  	
                  
                  <div class="form-group">
                    <label>Duration (In Whole Hours)</label>										
                    <input type="text" disabled id="number_of_hours" class="form-control"  value="0">
                    <input type="text" hidden id="number_of_hours_post" name="hours">
                  </div>
				  	
                  
                  <div class="form-group">
                    <label>Rate Per Page (Based on Duration)</label>	
                    <input type="text" disabled id="rate" class="form-control" value="$ 0">
                    <input type="text" hidden id="rate_post" name="price">
                  </div>
				  
                  
                  <div class="form-group">
                    <label>Number of Pages</label>
                    <input type="number" min="0.5" step="0.5" id="numPages"  oninput="calculateTot();" class="form-control" name="num_pages">
                  </div>
				  			
                  
                  <div class="form-group">
                    <label>Order Value</label>
                    <input type="hidden" id="orderValue" name="order_value">
                    <input type="text" disabled id="orderValueDisp" class="form-control" value="$ 0.00">
                  </div>
				  
                  <div class="form-group">
                    <label>Description</label>					
					<textarea rows="4" class="form-control" id="description" name="description" >Text...			
					</textarea>			
                  </div>
				  
				  
                  <div class="form-group">
                    <label>File Attachment</label>
                    <input type="file" class="form-control" name="file_upload" accept=".doc, .docx,.pdf"  placeholder="Choose file(word or pdf only)">
                  </div>				  
				  		
				

                <div class="form-goup">
				<label id="postResp"></label>
                  <button type="submit" class="btn btn-primary pull-right">Submit Order</button>
                </div>	

                <div class="form-goup">
                  <div>
				  
</div>

<script>
 function calculateTot(){
	 
	 
	
	//time calculation

	var deadline = document.getElementById("deadline").value;
    var dateObj = new Date(deadline);	 
	 
	 var today_date = new Date();
	 
	 
	 

	 
	 var diff = dateObj.valueOf() - today_date.valueOf();
	 var hours = Math.floor(diff/1000/60/60);
	 
	 	 if(hours<-1)
		 {
			 alert("Please a date equal to or greater than today's date.");				 
			 document.getElementById('deadline').value ='';
		 }
		 else if(hours>4380)
		 {
			 alert("Please select a duration equal to or less than 6 months.")
			 document.getElementById('deadline').value ='';
			}
			 else{
	 
	 //calculation of amount
	 var price_pg=0;
	 
	 if((hours>=0)&&(hours<=5)){price_pg='20';}
	 else if((hours>=6)&&(hours<=10)){price_pg='15';}
	 else if((hours>=11)&&(hours<=14)){price_pg='12';}
	 else if((hours>=15)&&(hours<=23)){price_pg='10';}
	 else if(hours>=24){price_pg='8';}
	 else{hours='0';}
	 
	 
	 
	 var num_pg = document.getElementById('numPages').value;
	 var tot = num_pg*price_pg;
	 document.getElementById('orderValue').value = tot.toFixed(2);
	 document.getElementById('orderValueDisp').value = '$ '+ tot.toFixed(2).replace(/\B(?=(?=\d*\.)(\d{3})+(?!\d))/g,',');
	

	 
	 document.getElementById('number_of_hours_post').value = hours;
	 document.getElementById('number_of_hours').value = hours;
	 document.getElementById('rate').value ='$ '+ price_pg;
	 document.getElementById('rate_post').value =price_pg;
 }
 }
</script>





                </div>		

				
				  
                </div>
				
				
	</div>
              </form>
            </div>
			
          
		  
        </div>
		
      </div>
	  
    </section>
	
  </div>
  
</div>






<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>-->


<script>
	$( document ).ready(function() {
		$("#phoneField1").CcPicker();
		$("#phoneField1").CcPicker("setCountryByCode","es");
		$("#phoneField3").CcPicker({"countryCode":"us"});
		$("#phoneField5").CcPicker();
		$("#phoneField1").on("countrySelect", function(e, i){
			
			
			document.getElementById('phoneField2').value =i.countryName;
			document.getElementById('counrtyField').value =i.countryName;
			document.getElementById('phoneCodeField').value =i.phoneCode;
												//alert(i.countryName + " " + i.phoneCode);
											});
	});
</script>



<!--Post data by jquery-->
 <script>
  
 $(document).ready(function (e) {
 $("#orderForm").on('submit',(function(e) {
  e.preventDefault();
  $.ajax({
         url: "post.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   beforeSend : function()
   {
	 
     $("#postResp").append("<i class='fa fa-spinner fa-spin'></i> Saving...");
   },
	success: function (data)
		{
		   $("#postResp").html(data);
			$("#orderForm")[0].reset();
			
			setTimeout(function () {
				window.location.href = 'login.php';
				}, 2000);

		}

 ,
     error: function(e) 
      {
    $("#postResp").html(e).fadeIn();
      }          
    });
 }));
}); 
  
  </script>

</body>
</html>
