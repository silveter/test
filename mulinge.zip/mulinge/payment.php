<?php
include_once('functions.php');

//Set useful variables for paypal form
$paypal_link = "https://www.sandbox.paypal.com/cgi-bin/webscr"; //Test PayPal API URL
$paypal_username = 'silvesterkisalu@gmail.com'; //Business Email

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Order Payment</title>
</head>
<style>
fieldset {
  background: #f5f3e0;
  width:300px;
  display: block;
  margin-left: 2px;
  margin-right: 2px;
  padding-top: 0.35em;
  padding-bottom: 0.625em;
  padding-left: 0.75em;
  padding-right: 0.75em;
  border: 2px groove (internal value);
 
}
.dot {
  height: 30px;
  width: 30px;
  background-color: green;
  border-radius: 50%;
  display: inline-block;
  padding-top: 0.35em;
  margin-top: -20px;
  float:right;
}
</style>
<body style="align:center;">
<fieldset>
	<?php
		//fetch products from the database
		if(isset($_POST['pay_id'])){
			
		}
		$results = $conn->query("SELECT orderid,price FROM orderdetails where orderid='".$_POST['pay_id']."'");
		$row = $results->fetch_assoc();
	?>
    
    <div id="paydetail"style="color: green;">Order Id: <?php echo $_POST['pay_id']; ?>
    <div id="amount" style="color: red;font-size:20px;"><span class="dot">$<?php echo $row['price']; ?></span></div>
	</div>
	<br/>
    <form action="<?php echo $paypal_link; ?>" method="post">

         <!-- Identify your business so that you can collect the payments. -->
        <input type="hidden" name="business" value="<?php echo $paypal_username; ?>">
        
        <!-- Specify a Buy Now button. -->
        <input type="hidden" name="cmd" value="_xclick">
        
        <!-- Specify details about the item that buyers will purchase. -->
        <input type="hidden" name="item_name" value="<?php echo $row['orderid']; ?>">
        <input type="hidden" name="amount" value="<?php echo $row['price']; ?>">
        <input type="hidden" name="currency_code" value="USD">
        
        <!-- Specify URLs -->
        <input type='hidden' name='cancel_return' value='http://localhost/paypal_integration_php/paypal_cancel.php'>
		<input type='hidden' name='return' value='http://localhost/paypal_integration_php/paypal_success.php'>
				    

        
        <!-- Display the payment button. -->
        <input type="image" name="submit" border="0"
        src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif" alt="PayPal - The safer, easier way to pay online">
        <img alt="" border="0" width="1" height="1" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" >  
    </form>
   
</fieldset>

</body>
</html>
