<?php 
include('functions.php'); 
include('menu.php') ;
?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration system PHP and MySQL</title>
	<style>
	hr.new1 {
  border-top: 3px dashed orange;
}
	</style>
</head>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<body>

<form style="margin-top:10px;padding-bottom: 0px;" method="post" action="sign_up.php">
<?php echo display_error(); ?>
<h2 style="color:orange;">Sign up</h2>
<div style="text-align:left;margin-left: 10px;margin-top: 20px;"id="contact"> 

<hr class="new1">
</div>
	<div class="input-group">
		<label>Username</label>
		<input type="text" name="username" value="">
	</div>
	<div class="input-group">
		<label>Email</label>
		<input type="email" name="email" value="">
	</div>
	<div class="input-group">
		<label>Password</label>
		<input type="password" name="password_1">
	</div>
	<div class="input-group">
		<label>Confirm password</label>
		<input type="password" name="password_2">
	</div>
	<div class="input-group">
		<button style="margin-left:80px;"type="submit" class="btn" name="register_btn">Register</button>
		Already a member? <a href="login.php" style="color:blue;font-size: 18px;"><i class="fa fa-sign-in" 
		   style="font-size:15px;color:green"></i>Log in</a>
	</div>
	<p>
		
	</p>
</form>
</body>
</html>