<?php

include_once('functions.php');
include_once('admin_menu.php');

				
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Orders in Progress</title>
    </head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

</style>
    <body>

<?php
if(isset($_POST['pick_id'])){
		$result = $conn->query("update orderdetails set assigned='Y' WHERE orderid='".$_POST['pick_id']."'");
		
		
}
		//fetch products from the database
		
		$results = $conn->query("SELECT * from orderdetails WHERE assigned='Y' and returned='' and completed=''");
		
		//$row = $results->fetch_assoc();
?>
<table style="margin-bottom:20px;margin-top:-250px;margin-left: 13%;" width="800" border="1" cellpadding="1" cellspacing='1'>

        <tr bgcolor="#00BFFF">
                                     
					 
					 <th>Order Id</th>
					 <th>Topic</th>
					 <th>Price</th>
					
                     
           </tr>
        

           
<?php

if (mysqli_num_rows($results) >0) 

{
while($row = $results->fetch_assoc()){

 echo "<tr>"
	.'<td><a href="submitorder.php?id=' . $row["orderid"].'">' . $row["orderid"].'</a></td>'
	."<td>".$row["sub_area"]."</td>"
	."<td>".$row["price"]."</td>";	
"</tr>";
    }
    }
    
 else {
    echo "";
	
}

mysqli_close($conn);
?> 
          
          
           </table>


   </body>

</html>