<!DOCTYPE html>
<?php
 //include('student_menu.php');
?>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Homepage</title>   
		 <link rel="stylesheet" href="Home1.css">
		 <link rel="stylesheet" href="generalorder.css">
		  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
		 <style>
table, th, td {
  border: 0px solid black;
}
ul {
		list-style: none;
			}	
		ul li:before {
		content: '✓'; 
					}
					#lists
					{
						
						background-color:beige;
						color: black;
						font-size: 22px;
					}
.quantity {
	position: relative;
	width: 100%;
	margin-bottom: 20px;
	margin-left: 2%;
}

.quantity input[type=number] {
	-moz-appearance: textfield;
}

.quantity input {
	width: 75%;
	padding: 0px;
	padding-left: 10px;
	margin-bottom: 10px;
}

.quantity input:focus {
	outline: 0;
}

.quantity-button {
	cursor: pointer;
	border: solid 1px solid #eee;
	width: 26px;
	text-align: center;
	color: #333;
	-moz-user-select: none;
	-ms-user-select: none;
	-o-user-select: none;
	user-select: none;
}

.quantity-button.quantity-up,
.quantity-button.quantity-down,
.quantity input {
	border: solid 1px #ccc;
	display: inline-block;
	height: 42px;
	line-height: 40px;
}

.quantity-button.quantity-up {
    color:black;
	background:silver;
}

.quantity-button.quantity-down {
	float: left;
	color:black;
	background-color:silver;
	
}

</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
       </head>
<body style="height:500px;width:100%;margin-left: 0px;margin-right: 0px;margin-bottom: 0px;margin-top:0px;">	
<section id="links">
<div id="black-div">
 <div style="transform: translateY(50%);float:left;"id="corpname">  
<img src="images/ESSAY-CORP.jpg" height="80" width="80" style="margin-top:-30px;">
 </div>
 <br>
                <a href="#why-us">About us</a>				
                <a href="#how-it-works">How it works</a>
				
               <a href="#pricing">Pricing</a>
				
              <a href="#customer-say">Reviews</a>
			  <a href="#">Contact us</a>
			 			 
			<!--<button style="color: white;background-color:green; width:150px; height:35px;font-weight:bold;font-size:20px;border-radius:30px;" onclick="document.location = '#orderdetails.php'">Order Now</button>-->	
			
                  <div style="float: right;" id="profile">
				   <a href="sign_up.php" style="color:darkblue; black;">Register</a>
                   <a href="login.php" style="color: darkblue;">Log in</a>					 
                  </div>       

     </div>
</section>
<section style="background-color:#937D14;height:520px;margin-top:-22px;margin-left:0%;"id="animate">
 <h1 style="color:#f5f5f5;font-family: Impact, Charcoal, sans-serif;margin-left:1%;">Welcome to EssaysCorp for Essay Writing Services</h1>

<img src="images/caption1.jpg" height="400" width="550">

<form style="background-color:#F5F5F5;width:30%;height:99%;float:right;margin-right:5%;margin-top:-52px;"action="form.php" method="POST" name="login-form">
<div id="order-info" class="tabcontent">
    <h1 style="text-align:center;color:darkblue;">Get A+ Quote</h1>
                            
                   <select id="doc_type" name="doc_type" required>
								<option value="Research Paper">Research Paper</option>
								<option value="Term Paper">Term Paper</option>
								<option value="Essay">Essay</option>
								<option value="Report">Report</option>
								<option value="Speech">Speech</option>
								<option value="Presentation">Presentation</option>
								<option value="Research Proposal">Research Proposal</option>
								<option value="Thesis">Thesis</option>
								<option value="Proofreading">Proofreading</option>
								<option value="Personal Statement">Personal Statement</option>
								<option value="Outline">Outline</option>
								<option value="literature Review">Literature Review</option>
				</select>
							  
							   <select id="sub_area" name="sub_area">
								<option value="Computer Science">Computer Science</option>
								<option value="Biology">Biology</option>
								<option value="Business">Business</option>
								<option value="Chemistry">Chemistry</option>
								<option value="Information Technology">Information Technology</option>
								<option value="Environmental Science">Environmental Science</option>
								<option value="Technology">Technology</option>
								<option value="Cultural Studies">Cultural Studies</option>
								<option value="English">English</option>
								<option value="English Literature">English Literature</option>
								<option value="Marketing">Marketing</option>
								<option value="Finance">Finance</option>
					</select>
					<select id="level" name="level">
								<option value="Highscool">High School</option>
								<option value="College">College</option>
								<option value="University">University</option>
								<option value="Masters">Masters</option>
								<option value="Post Graduate">Ph.D</option>
								<option value="Doctoral">Doctoral</option>
								
					</select>
					<!--<select id="pages" name="pages">
								<option value="1">1 Pages</option>
								<option value="2">2 Pages</option>
								<option value="3">3 Pages</option>
								<option value="4">4 Pages</option>
								<option value="5">5 Pages</option>
						
								
					</select>-->
<div class="quantity"><input type="number" min="0" max="100" step="1" value="0">
</div>

	<button style="color: white;background-color:#004f49; width:250px; height:40px;font-weight:bold;font-size:20px;border-radius:1px;margin-left:20%;border-radius:5px;" onclick="document.location = 'form.php'">Order Now</button>
</form>
		
</section>
<section>
    <h1 style="font: 25px Arial, sans-serif;text-decoration-color:blue;font-family: Impact, Charcoal, sans-serif;margin-left:2%;">Your Trusted Assignment Services</h1>
<fieldset style="width:15%;height:100px;background-color:white;border: 2px solid orange;margin-left:1%;border-radius:5px;">
		<legend><i class="fa fa-thumbs-o-up" style="font-size:48px;color:orange;"></i></legend>
		Quality Grades are Guaranteed.
</fieldset>

<fieldset style="width:15%;height:100px;align:center;margin-left:25%;background-color:#ABB2B9;margin-top:-120px;border:
		2px solid orange;border-radius:5px;border-radius:5px;"><legend>
		<i class="fa fa-pencil-square-o" style="font-size:48px;color:black"></i></legend>Hire Experienced and Professional Writers.
</fieldset>
<fieldset style="width:15%;height:95px;margin-left:50%;background-color: white;margin-top:-120px;border: 2px solid orange;
		border-radius:5px;"><legend><i class="fa fa-check-circle"style="font-size:24px;color:orange;"></i>
		</legend>Customer Satisfaction is Our Priority.
</fieldset>
<fieldset style="width:15%;height:100px;align:center;margin-left:75%;background-color: white;margin-top:-130px;border:
		2px solid orange;border-radius:5px;border-radius:5px;"><legend>
		<i class="fa fa-search" style="font-size:24px;color:orange;"></i></legend>We Screen Your Paper to Make You Happy.
</fieldset>
</section>
<section style="background-color:#787878;height:300px;font-size:20px;"id="customer-say">
    <p style="font-family: Impact, Charcoal, sans-serif;text-align:center;color:white;">What EssaysCorp Customers Say</p>
		
</section>
<section style="height:400px;font-size:25px;"id="core-values">
<p style="margin-left:2%;font-family: Impact, Charcoal, sans-serif;">Our Promises</p>
<p style="margin-left:1%;">At our writing company EssaysCorp, customer satisfaction is our <br></br>top priority. 
All our papers are written with strict conformity <br></br>with your needs and those of the professor.
We take keen <br></br>concern towards quality and plagiarism free work.
</p>
		</section>
<section style="background-color:#FCFCFC;height:250px;"id="pricing">
<p style="font-weight:none;text-align:center;font-family: Impact, Charcoal, sans-serif;font-size:25px;">EssaysCorp Custom Pricing<p>

<table style="width:80%;text-align:center;margin-left: 10%;">
  <tr style="color:#FF6347;font-size:30px;">
   
    <th>High School</th>
    <th>College</th>
	<th>University</th>
	<th>Masters</th>
	<th>Ph.D</th>
  </tr>
  <tr style="font-size:25px;background-color:#A3E4D7">
    <td>$8</td>
	<td>$10</td>
	<td>$12</td>
	<td>15</td>
	<td>$18</td>
</table>


</section>

		<section style="background-color:beige;height:400px; font-size:25px;"id="contact-us">
		<p style="font-family: Impact, Charcoal, sans-serif;margin-left:1%;">What defines EssaysCorp services</p>
<div id="lists" style="margin-left:1%;">
<ul type="tick">
         <li>Best Experts at Affordable Prices</li></br>
         <li >We are a Leading company in Assignment Help</li></br>
         <li>24/7 Guaranteed Support and Ticketing Available</li></br>
         <li>QualityGgrades From our Qualified Experts</li>
</ul>
</div> 
		</section>
<section style="background-color:#FFFFFF;height:300px;font-size:20px;"id="why-us">
		<p style="font-weight:bold;font-family: Impact, Charcoal, sans-serif;margin-left:2%;">Why Us?</p>
<p style="margin-left:1%;">We have editors who keenly proofread the papers to ensure all instructions are adhered to.<br></br>
A refund of 40% if the customer gets a failing grade from our services.
You can access the <br></br>Plagiarism report from our site.
We are available 24/7
Offer bonus services after a particular<br></br>number has been completed from the same client. 
</p>
		</section>
<?php
include ('supportchat.php');
?>
	<script>
	    jQuery('<div class="quantity-button quantity-up">+</div><div class="quantity-button quantity-down">-</div>').insertAfter('.quantity input');
    jQuery('.quantity').each(function () {
        var spinner = jQuery(this),
        input = spinner.find('input[type="number"]'),
        btnUp = spinner.find('.quantity-up'),
        btnDown = spinner.find('.quantity-down'),
        min = input.attr('min'),
        max = input.attr('max');

        btnUp.click(function () {
            var oldValue = parseFloat(input.val());
            if (oldValue >= max) {
                var newVal = oldValue;
            } else {
                var newVal = oldValue + 1;
            }
            spinner.find("input").val(newVal);
            spinner.find("input").trigger("change");
        });

        btnDown.click(function () {
            var oldValue = parseFloat(input.val());
            if (oldValue <= min) {
                var newVal = oldValue;
            } else {
                var newVal = oldValue - 1;
            }
            spinner.find("input").val(newVal);
            spinner.find("input").trigger("change");
        });

    });
	</script>	
</body>
</html>


