<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title></title>
        <link rel="stylesheet" href="Home.css">
		
        </head>
		<style>
   
    </style>
        <body>
     <div id="black-div">
                
                |<a href="Home.php">About us</a>|				
                <a href="#tag_a.asp">How it works</a>| 
				
               <a href="#test.php">Pricing</a>|
				
              <a href="#">Reviews</a>|
			  <a href="#">Contact us</a>
			 			 
			<button style="color: white;background-color:green; width:150px; height:35px;font-weight:bold;font-size:20px;border-radius:30px;" onclick="document.location = 'login.php'">Order Now</button>	
			
                  <div style="float: right;" id="profile">
				   <a href="sign_up.php" style="color:white; black;backgroud_color: white">Register</a>
                   <a href="login.php" style="color: black;">Log in</a>					 
                  </div>       

     </div>
	  
	
   </body>
</html>